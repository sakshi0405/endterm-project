import React from 'react';

import Signup from '../Components/Signup/Signup';

function SignupPage() {
  return (
    <div>
      <Signup />
    </div>
  );
}

export default SignupPage;
